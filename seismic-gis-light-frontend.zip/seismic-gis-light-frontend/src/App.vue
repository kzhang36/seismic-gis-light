<template>
  <EarthquakeMap />
</template>

<script setup>
import EarthquakeMap from './components/EarthquakeMap.vue';
</script>
